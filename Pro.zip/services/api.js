import { BASE_URL, HTTP_ERROR } from '../config/index'

/**
 * 检查http状态值
 * @param response
 * @returns {*}
 */
function checkHttpStatus(response) {
  dd.stopPullDownRefresh()
  if (response.statusCode >= 200 && response.statusCode < 300) {
    return response.data
  } else if (response.statusCode == 400) {
  }
  const message =
    HTTP_ERROR[response.statusCode] || `ERROR CODE: ${response.statusCode}`
  const error = new Error(message)
  error.data = response.data
  error.text = message
  error.code = response.statusCode
  throw error
}

/**
 * 检查返回值是否正常
 */
function checkSuccess(data) {
  if (data instanceof ArrayBuffer && typeof data === 'string') {
    return data
  }

  const { data: respData } = data
  if (typeof respData.code === 'number' && respData.code === 0) {
    return respData
  }
  const message = respData.msg || '服务器异常'
  const error = new Error(message)
  error.data = respData.data
  error.text = respData.msg
  error.code = data.code
  throw error
}

/**
 * 请求错误处理

 */
function throwError(err) {
  const error = new Error(err.errMsg || '服务器正在维护中!')
  error.code = 500
  throw error
}

// 添加事件结束
Promise.prototype.finally = function(callback) {
  var Promise = this.constructor;
  return this.then(
    function(value) {
      Promise.resolve(callback()).then(
        function() {
          return value;
        }
      );
    },
    function(reason) {
      Promise.resolve(callback()).then(
        function() {
          throw reason;
        }
      );
    }
  );
}

export default {
  request(url, options) {
    const token = dd.getStorageSync('token') || ''
    return new Promise((resolve, reject) => {
      dd.httpRequest({
        ...options,
        url: `${BASE_URL}${url}`,
        header: {
          'Content-Type': 'application/json',
          ...options.header,
          Authorization: `Bearer ${token}`,
        },
        success: function(response) {
          console.log('success', response);
          const { status, data: respData = {} } = response
          if (status >= 200 && status < 300) {
            if (typeof respData.code === 'number' && respData.code === 0) {
              resolve(respData);
            } else {
              reject(respData.msg || '未知错误');
            }
          } else {
            reject(respData.msg || '未知错误');
          }
        },
        fail: function(res) {
          reject('请求错误')
        },
        complete: function(res) {
          console.log(res);
        },
      })
    })
  },
  get(url, data = {}, options = {}) {
    return this.request(url, {
      data,
      ...options
    })
  },
  post(url, data = {}, options = {}) {
    return this.request(url, {
      method: 'POST',
      data: data,
      ...options,
    },
    )
  },
  put(url, data = {}, options = {}) {
    return this.request(url, {
      method: 'PUT',
      data: data,
      ...options,
    },
    )
  },
  delete(url, data = {}, options = {}) {
    return this.request(url, {
      method: 'DELETE',
      data: data,
      ...options,
    },
    )
  },
}