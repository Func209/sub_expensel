<template>
	<view>
		<form @submit="formSubmit" @reset="formReset">
		    <view class="uni-form-item uni-column">
		        <view class="title">报销金额</view>
		        <input class="uni-input" focus placeholder="请输入金额" />
		    </view>
			<view class="uni-form-item uni-column">
			    <view class="title">报销类别</view>
			    <input class="uni-input" focus placeholder="如:采购经费.活动经费" />
			</view>
			<view class="uni-form-item uni-column">
			<view class="title">费用明细</view>
			        <view class="uni-textarea">
			            <textarea class="uni-input text_detail"  auto-height placeholder="请输入费用明细描述" />
			            </view>
			</view>
			</form>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			formSubmit: function(e) {
			    console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
			    var formdata = e.detail.value
			    uni.showModal({
			        content: '表单数据内容：' + JSON.stringify(formdata),
			        showCancel: false
			    });
			},
			formReset: function(e) {
			    console.log('清空数据')
			}
		}
	}
</script>

<style>

</style>
