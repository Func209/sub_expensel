<template>  
    <view>  
        <view type="file" ref="input" class="input"></view>
        <!-- <view @tap="uploadBtn">
        <text>请选择</text><uni-icon type="forward" size=18></uni-icon> -->
        </view> 
    </view>  
</template>  

<script>  
    export default {  
        mounted() {
        var input = document.createElement('input')
        // input.style.display = 'none'
        input.type = 'file'
        input.id = 'file';
		// input.setAttribute("style","color:red")
        var _this = this;
        this.$refs.input.$el.appendChild(input);
        input.onchange = (event) => {
        var file = event.target.files[0]; 
        //上传方法
        _this.uploadAPI(file)
           }
        },
        methods:{
			uploadBtn() {
				// return document.getElementById("file").click();
			},
			uploadAPI(path) {
				var fData = new FormData();
				fData.append("file",path);
				var xhr = new XMLHttpRequest();
				xhr.open("POST",'http://10.180.22.91/fic/default1.aspx?type=SET' , true);
				xhr.onload = function(e) { 
				console.log(e);	//上传成功
				};
				xhr.send(fData)
			},
		}
    }  
</script>  

<style> 
.imageUpload{
		width: 80upx;
		height: 80upx;
		margin: 10upx;
		line-height: 70upx;
		text-align: center;
		font-size: 70upx;
		color: #D9D9D9;
		border: 1px solid #D9D9D9;
		border-radius: 8upx;
	}
</style>