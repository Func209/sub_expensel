<template>
	<view>
		<view class="content">
			<!-- <div style="height: 100vh">
				<lis-tree class="tree" :root="root" :checked="checked" show-checkbox :change-handler="onChange" auto-expand></lis-tree>
			</div> -->
			<!-- <text>一些参数</text> -->
			<tki-tree ref="tkitree" :selectParent="true" :multiple="true" :range="list" rangeKey="name" @confirm="treeConfirm" @cancel="treeCancel"></tki-tree>
		</view>
	</view>
</template>

<script>
	import {uniBadge,uniList,uniListItem} from '@dcloudio/uni-ui'
	import tkiTree from '@/components/tree/tki-tree.vue';
	import lisTree from '@/components/lis-tree/lis-tree.vue';
	let testList = [
		{
			id: 1,
			name: '北京市',
			children: [
				{
						id: 111,
						name: '西城区',
					},
					{
						id: 112,
						name: '东城区',
					},
					{
						id: 113,
						name: '朝阳区',
					},
					{
						id: 113,
						name: '丰台区',
					},
					]
		},
		{
			id: 2,
			name: '河北省',
			children: [{
					id: 21,
					name: '石家庄市',
				},
				{
					id: 22,
					name: '唐山市',
				},
				{
					id: 23,
					name: '秦皇岛市',
				},
			]
		},
		{
			id: 3,
			name: '山东省',
			children: [{
					id: 31,
					name: '济南市',
				},
				{
					id: 32,
					name: '青岛市',
				},
				{
					id: 33,
					name: '临沂市',
				},
				{
					id: 34,
					name: '日照市',
				},
				{
					id: 35,
					name: '淄博市',
				},
				{
					id: 36,
					name: '枣庄市',
				},
			]
		},
		{
			id: 4,
			name: '河南省',
			children:[
				{
					id: 41,
					name: '泰安市',
				},
				{
					id: 42,
					name: '威海市',
				},
				{
					id: 43,
					name: '滨州市',
				},
				{
					id: 44,
					name: '菏泽市',
				},
			]
		},
		{
			id: 5,
			name: '湖北省',
			children:[
				{
					id: 41,
					name: '泰安市',
				},
				{
					id: 42,
					name: '威海市',
				},
				{
					id: 43,
					name: '滨州市',
				},
				{
					id: 44,
					name: '菏泽市',
				},
			]
		},
	]
	export default {
		data() {
			return {
				list: [],
				root: {},
				selected: null,
				checked: [],
			}
		},
		onLoad() {
			setTimeout(()=>{
				this.list = testList;
			}, 300)
		},
		// onLoad() {
		// 	setTimeout(() => {
		// 		this.root = {
		// 			children: [{
		// 					id: 'jiangsu',
		// 					name: '江苏省',
		// 					children: [{
		// 						id: 'nanjing',
		// 						name: '南京市',
		// 						children: [{
		// 								id: 'pukou',
		// 								name: '浦口区',
		// 							},
		// 							{
		// 								id: 'jiangning',
		// 								name: '江宁区',
		// 							}
		// 						]
		// 					}, ]
		// 				},
		// 				{
		// 					id: 'zhejiang',
		// 					name: '浙江省',
		// 					children: [{
		// 						id: 'hangzhou',
		// 						name: '杭州市',
		// 						children: [{
		// 							id: 'yuhang',
		// 							name: '余杭区',
		// 						}, ]
		// 					}, ]
		// 				},
		// 			]
		// 		}
		// 		this.selected = {
		// 			id: 'pukou',
		// 		}
		// 		this.checked = [{
		// 			id: 'jiangning'
		// 		}]
		// 	}, 1000)
		// },
		components: {uniBadge, uniList,uniListItem,tkiTree,lisTree},
		methods: {
			onChange(selected) {
				console.log(selected);
			},
			// 确定回调事件
			treeConfirm(e){
				console.log(e)
			},
			// 取消回调事件
			treeCancel(e){
				console.log(e)
			},
			// 显示树形选择器
			showTree(){
				this.$refs.tkitree._show();
			},
		}
	}
</script>

<style>

</style>
