<template>
    <view>
        <view>
            <form @submit="formSubmit" @reset="formReset">
				<view v-for="(item,index) in items" :key=index>
					<view class="title_index">
						<text>报销明细({{index+1}})</text>
						<text class="title_del" v-if="index > 0" @click="delNodes(index)">删除</text>
						</view>
                    <view class="uni-form-item uni-column" v-bind:id="'amount'+ index">
                       <view class="title">报销金额</view>
                       <input class="uni-input" focus placeholder="请输入金额" />
                    </view>
				    <view class="uni-form-item uni-column" v-bind:id="'category'+index">
				       <view class="title">报销类别</view>
				       <input class="uni-input" placeholder="如:采购经费.活动经费" />
				    </view>
				   <view class="uni-form-item uni-column" v-bind:id="'cost'+index">
				         <view class="title">费用明细</view>
				         <view class="uni-textarea">
				            <textarea class="uni-input text_detail"  auto-height placeholder="请输入费用明细描述" />
				         </view>
				   </view>
				</view>
				    <view class="add_node" style="text-align: center;" @click="addNodes">+增加报销明细</view>
				<view>
					<view class="title">图片</view>
					<!-- <robby-image-upload v-model="imageData" @delete="deleteImage" @add="addImage" :server-url="serverUrl" :form-data="formData" :header="header"></robby-image-upload> -->
					<image-upload :upImgConfig="upImgBasic" @onUpImg="upBasicData" @onImgDel="delImgInfo" ref="uImage"></image-upload>
				</view>
				<view>
					<view class="title">附件</view>
					<!-- <robby-image-upload v-model="imageData" @delete="deleteImage" @add="addImage" :server-url="serverUrl" :form-data="formData" :header="header"></robby-image-upload> -->
					<file-upload @parentFn='testFn()'></file-upload>
				</view>
				<view class="uni-form-item uni-column">
				    <view class="title">备注</view>
				    <input class="uni-input" placeholder="请输入备注" />
				</view>
				<view>
					<step
					@showTree='showFn()'
					:options="[{title:'审批人',add:'1'},
					{title:'审批人',add:'1'},
					{title:'审批人',add:'1'},
					{title:'审批人',add:'1'},
					{title:'抄送人',add:'1'}]" 
					direction="column" :active="2">
					</step>
				</view>
				<view class="content">
					<tree ref="tkitree" :selectParent="true" :multiple="true" :range="list" rangeKey="name" @confirm="treeConfirm" @cancel="treeCancel"></tree>
				</view>
                <view class="uni-btn-v clearfix">
                    <button class="sub_btn" form-type="submit">提交</button>
                </view>
				<!-- <uni-list>
				    <uni-list-item title="标题文字" note="描述信息">123</uni-list-item>
				    <uni-list-item title="标题文字" note="描述信息" :show-badge="true" badge-text="12">123</uni-list-item>
				</uni-list> -->
            </form>
        </view>
    </view>
</template>
<script>
	import Tree from '@/components/tki-tree/tki-tree.vue';
	import robbyImageUpload from '@/components/robby-image-upload/robby-image-upload.vue'
	import fileUpload from'@/components/file-upload/file-upload.vue'
	import applyDetail from'@/components/apply-detail/apply-detail.vue'
	import imageUpload from '@/components/image-upload/sunui-upimg-basic.vue'
	import {uniBadge,uniList,uniListItem} from '@dcloudio/uni-ui'
	import step from '@/components/steps/steps.vue'
	
	let testList = [{
			id: 1,
			name: '北京市',
				children: [{
						id: 111,
						name: '西城区',
					},
					{
						id: 112,
						name: '东城区',
					},
					{
						id: 113,
						name: '朝阳区',
					},
					{
						id: 114,
						name: '丰台区',
					}
				]
		},
		{
			id: 2,
			name: '河北省',
			children: [{
					id: 21,
					name: '石家庄市',
				},
				{
					id: 22,
					name: '唐山市',
				},
				{
					id: 23,
					name: '秦皇岛市',
				},
			]
		},
		{
			id: 3,
			name: '山东省',
			children: [{
					id: 31,
					name: '济南市',
				},
				{
					id: 32,
					name: '青岛市',
				},
				{
					id: 33,
					name: '临沂市',
				},
				{
					id: 34,
					name: '日照市',
				},
			]
		},
		{
			id: 4,
			name: '河南省',
			children:[
				{
					id: 41,
					name: '泰安市',
				},
				{
					id: 42,
					name: '威海市',
				},
				{
					id: 43,
					name: '滨州市',
				},
				{
					id: 44,
					name: '菏泽市',
				},
			]
		},
		{
			id: 5,
			name: '湖北省',
			children:[
				{
					id: 38,
					name: '潍坊市',
				},
				{
					id: 39,
					name: '烟台市',
				},
				{
					id: 40,
					name: '济宁市',
				},
			]
		},
		{
			id: 6,
			name: '湖南省',
			children:[
				{
					id: 35,
					name: '淄博市',
				},
				{
					id: 36,
					name: '枣庄市',
				},
				{
					id: 37,
					name: '东营市',
				},
			]
		}
	]
	
    export default {
        data() {
            return {
				list: [],
				formData:new FormData(),
				imageData :[],
				items:[0],
				count:0,
				basicArr: [],
				// 基础版配置
				upImgBasic: {
					// 后端图片接口地址
					basicConfig: {
						url: 'https://p.dns06.net.cn/index.php?m=Api&c=index&a=upload'
					},
					// 是否开启提示(提醒上传图片的数量)
					// tips: false,
					// 是否开启notli(开启的话就是选择完直接上传，关闭的话当count满足数量时才上传)
					notli: false,
					// 图片数量
					count: 2,
					// 相机来源(相机->camera,相册->album,两者都有->all,默认all)
					sourceType: 'camera',
					// 是否压缩上传照片(仅小程序生效)
					sizeType: true,
					// 上传图片背景修改 
					upBgColor: '#E8A400',
					// 上传icon图标颜色修改(仅限于iconfont)
					upIconColor: '#fff',
					// 上传svg图标名称
					// upSvgIconName: 'icon-card',
					// 上传文字描述(仅限四个字)
					// upTextDesc: '上传证书',
					// 删除按钮位置(left,right,bleft,bright),默认右上角
					delBtnLocation: '',
					// 是否隐藏添加图片
					// isAddImage: false,
					// 是否隐藏删除图标
					// isDelIcon: false,
					// 删除图标定义背景颜色
					// delIconColor: '',
					// 删除图标字体颜色
					// delIconText: '',
					// 上传图标替换(+),是个http,https图片地址(https://www.playsort.cn/right.png)
					iconReplace: ''
				}
            }
        },
		onLoad() {
			setTimeout(()=>{
				this.list = testList;
			}, 300)
		},
		components: {uniBadge, uniList,uniListItem, robbyImageUpload,fileUpload,applyDetail,step,Tree,imageUpload},
        methods: {
			// 确定回调事件
			treeConfirm(e){
				console.log(e)
			},
			// 取消回调事件
			treeCancel(e){
				console.log(e)
			},
			// 显示树形选择器
			showFn(){
				this.$refs.tkitree._show();
				console.log(this.$refs.tkitree)
			},
            formSubmit: function(e) {
                console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
                var formdata = e.detail.value
                uni.showModal({
                    content: '表单数据内容：' + JSON.stringify(formdata),
                    showCancel: false
                });
            },
            formReset: function(e) {
                console.log('清空数据')
            },
			addNodes() {
				this.items.push(this.count++)
				console.log(this.items)
			},
			delNodes(index) {
				console.log(index);
				this.items.splice(index,1)
			},
			// 删除图片 -2019/05/12(本地图片进行删除)
			async delImgInfo(e) {
				console.log('你删除的图片地址为:', e, this.basicArr.splice(e.index, 1));
			},
			// 基础版
			async upBasicData(e) {
				console.log('===>',e);
				// 上传图片数组
				let arrImg = [];
				for (let i = 0, len = e.length; i < len; i++) {
					try {
						if (e[i].path_server != "") {
							await arrImg.push(e[i].path_server.split(','));
						}
					} catch (err) {
						console.log('上传失败...');
					}
				}
				// 图片信息保存到data数组
				this.basicArr = arrImg;
			
				// 可以根据长度来判断图片是否上传成功. 2019/4/11新增
				if (arrImg.length == this.upImgBasic.count) {
					uni.showToast({
						title: `上传成功`,
						icon: 'none'
					});
				}
			},
        }
    }
</script>

<style>
    .title {
        padding: 10px 10px 0;
    }
	.text_detail{
		/* border-bottom: 1px solid #CCCCCC; */
		width: 100%;
		min-height: 50px;
	}
	.uni-input{
		border-bottom: 1px solid #ccc;
		padding: 4px;
	}
	.title,.uni-input{
		font-size: 14px;
		padding-left: 10px;
	}
	.title_index{
		background-color: #F1F1F1;
		line-height: 14px;
		padding:10px 5px;
		font-size: 10px;
	}
	.title_del{
		color: #09a0f7;
		float: right;
		padding-right: 10px;
	}
	.uni-btn-v{
		margin: 0 10px;
	}
	.sub_btn{
		width: 100%;
		position: fixed;
		bottom: 0;
		left: 50%;
		transform: translateX(-50%);
		z-index: 9999;
		background-color: #09a0f7;
		color: #fff;
	}
	.add_node{
		width: 100px;
		/* width: 80upx;
		height: 80upx; */
		line-height: 70upx;
		text-align: center;
		font-size: 25upx;
		color: #09a0f7;
		/* border: 1px solid #D9D9D9; */
		border-radius: 8upx;
		margin: 0 auto;
	}
	.clearfix{
		content: '';
		clear: both;
		display: block;
	}
</style>